import {StyleSheet} from 'react-native';

const styles = StyleSheet.create({
  headerStyle: {
    backgroundColor: '#004169',
    borderBottomLeftRadius: 30,
    borderBottomRightRadius: 30,
    height: 60,
  },
});
export {styles};
