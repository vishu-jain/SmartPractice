import React, {Component} from 'react';
import {Text, View} from 'react-native';
import Commonheader from '../../../components/common/commonheader';

export default function Leaderboard() {
  return (
    <View>
      <Text> User Dashboard </Text>
    </View>
  );
}
