const Images = {
  logo: require('./logoSmP.jpeg'),
  logo2: require('./smartpractice.png'),
  mainlogo: require('./logoSmPvert.png'),
};
module.exports = Images;
