const FONTS = {
  BOLD: 'Nunito-Bold',
  LIGHT: 'Nunito-Light',
  REGULAR: 'Nunito-Regular',
  SEMI_BOLD: 'Nunito-SemiBold',
  MEDIUM: 'Nunito-Medium',
  EXTRA_LIGHT: 'Nunito-ExtraLight',
  ITALIC: 'Nunito-Italic',
};

module.exports = FONTS;
