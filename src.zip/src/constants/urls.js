const URL = {
  BASE_URL: 'http://54.190.192.105:9185/angel/',
};

module.exports = URL;
